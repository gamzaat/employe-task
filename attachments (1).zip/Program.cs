﻿using Employe;

Employee em = new Employee("Gamza", "taghiyeva", 230, 3,200, "ofis");

Console.WriteLine(em.SalaryCheck(230));
Console.WriteLine(em.NameChecker("gamza"));
Console.WriteLine(em.SurnameChecker("Tagiyeva"));
